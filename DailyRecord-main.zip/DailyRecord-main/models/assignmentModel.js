const mongoose = require('mongoose');

const assignmentSchema = new mongoose.Schema({
  date: { type: Date, required: true },
  shift: { type: String, enum: ['morning', 'evening'], required: true },
  machine: {type: String, require: true},
  task: { type: String, required: true },
  members: [{ type: String, required: true }]
});

module.exports = mongoose.model('Assignment', assignmentSchema);
